/**
 * NotebookLM Enhancer - View Detector
 * Optimized for robust view state detection based on user-defined visibility rules.
 */
var ViewDetector = {
  /**
   * Check if we are currently in the main list view (Sources sidebar visible)
   */
  isMainListView() {
    // Characterize the main list by its scroll containers
    const scrollArea = document.querySelector('.scroll-area-desktop') || 
                       document.querySelector('.mat-drawer-inner-container') ||
                       document.querySelector('[class*="source-panel-content" i]');
    
    // A visible scroll area usually means we are in the main list
    const result = !!(scrollArea && (scrollArea.offsetWidth > 0 || scrollArea.offsetHeight > 0));
    return result;
  },

  /**
   * Check if the sidebar is natively collapsed or hidden
   * Rule: Hide only if a DOM has both 'source-panel' and 'panel-collapsed'
   */
  isNativeCollapsed() {
    // 1. Strict class-based detection
    const strictlyCollapsed = !!document.querySelector('.source-panel.panel-collapsed') || 
                              !!document.querySelector('[class*="source-panel" i].panel-collapsed');
    
    if (strictlyCollapsed) return true;

    // 2. Fallback: If no sidebar exists at all, consider it hidden
    const sidebar = document.querySelector('.mat-drawer') || 
                    document.querySelector('.source-panel') ||
                    document.querySelector('.scroll-area-desktop');
    if (!sidebar) return true;

    // 3. Physical check for robustness
    return sidebar.offsetWidth > 0 && sidebar.offsetWidth < 100;
  },

  /**
   * Check if we are currently in a view that should HIDE the toolbar
   * Rules: Hide if '.source-panel-view-content' or 'aria-modal="true"' is present.
   */
  isDocumentView() {
    const isNotebook = window.location.href.includes('/notebook/');
    if (!isNotebook) return false;

    // 1. Rule: Hide if Source detail is expanded
    const hasSourceViewContent = !!document.querySelector('.source-panel-view-content');
    
    // 2. Rule: Hide if any modal is active (Artifacts, Slide Decks, Infographics usually use this)
    const hasAriaModal = !!document.querySelector('[aria-modal="true"]');

    // 3. Fallback: Specific Studio/Document tags that might not use aria-modal
    const specialViewers = document.querySelectorAll('lb-source-viewer, lb-note-viewer, lb-slide-deck, lb-mind-map, lb-artifact-viewer');
    const hasActiveSpecialViewer = Array.from(specialViewers).some(el => {
      // For note-viewer, only trigger hide if it's expanded/wide (>300px)
      if (el.tagName.toLowerCase() === 'lb-note-viewer') {
        return el.offsetWidth > 300;
      }
      return el.offsetWidth > 0;
    });
    
    const result = hasSourceViewContent || hasAriaModal || hasActiveSpecialViewer;
    
    if (result) {
      console.log("[NB-Ext] Hide triggered via:", { hasSourceViewContent, hasAriaModal, hasActiveSpecialViewer });
    }
    return result;
  }
};
